# Required Fields

## What is it?

Use this plugin to append a marked up asterisk to the labels of required fields.
It determines this by looking at validations set on the object form helpers' properties to determine whether or not validatesPresenceOf() is set (manually or automatically).

## The Latest Version

The latest version of this script can always be found at the
Github project page which is located at
https://github.com/liquifusion/cfwheels-required-fields

## Documentation

Documentation on how to use this plug-in can be found at
http://cfwheels.org/plugins/listing/63

## Installation

Copy this ZIP file into your CFWheels /plugins folder and then reload your application.

## License

None specified